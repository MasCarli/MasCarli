import express from "express";
import mongoose from "mongoose";
import bodyParser from "body-parser";
import cors from "cors";
import fs from "fs";
import path from "path";
import axios from "axios";
import nodemailer from "nodemailer";

const __dirname = path.resolve();
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

const config = JSON.parse(fs.readFileSync("./config.json"));

// ===== MongoDB Connection =====
mongoose.connect(config.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ MongoDB error:", err));

// ===== Schema User =====
const userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  saldo: { type: Number, default: 0 },
  reffCode: String,
  referredBy: String
});
const User = mongoose.model("User", userSchema);

// ===== Register =====
app.post("/api/register", async (req, res) => {
  const { username, email, password } = req.body;
  const exist = await User.findOne({ email });
  if (exist) return res.status(400).json({ message: "Email sudah terdaftar" });

  const newUser = new User({ username, email, password });
  await newUser.save();

  // kirim ke Telegram owner
  if (config.BOT_TOKEN && config.OWNER_ID) {
    axios.post(`https://api.telegram.org/bot${config.BOT_TOKEN}/sendMessage`, {
      chat_id: config.OWNER_ID,
      text: `👤 User baru terdaftar:\nUsername: ${username}\nEmail: ${email}`
    });
  }

  res.json({ message: "Registrasi berhasil! Verifikasi dikirim ke email." });
});

// ===== Login =====
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (!user) return res.status(400).json({ message: "Email atau password salah" });
  res.json({ message: "Login sukses", user });
});

// ===== Deposit Request =====
app.post("/api/deposit", async (req, res) => {
  const { username, amount, metode } = req.body;
  if (config.BOT_TOKEN && config.OWNER_ID) {
    axios.post(`https://api.telegram.org/bot${config.BOT_TOKEN}/sendMessage`, {
      chat_id: config.OWNER_ID,
      text: `💰 Permintaan Deposit Baru\nUsername: ${username}\nJumlah: Rp${amount}\nMetode: ${metode}\n\n[KONFIRMASI] / [TOLAK]`
    });
  }
  res.json({ message: "Permintaan deposit dikirim ke owner." });
});

// ===== Start Server =====
app.listen(config.PORT, () => {
  console.log(`🚀 Server berjalan di port ${config.PORT}`);
});