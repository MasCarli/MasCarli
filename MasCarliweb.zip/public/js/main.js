// === MasCarli Web App ===

// Cek status login
document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("user"));
  const loginBtn = document.getElementById("login-btn");

  if (loginBtn) {
    if (user) {
      loginBtn.textContent = "Profil";
      loginBtn.href = "dashboard.html";
    } else {
      loginBtn.textContent = "Login";
      loginBtn.href = "login.html";
    }
  }

  // Tampilkan produk di beranda
  if (document.getElementById("productList")) {
    loadProducts();
  }
});

// === Fungsi Ambil Produk dari Database ===
async function loadProducts() {
  try {
    const res = await fetch("/api/products");
    const products = await res.json();
    const container = document.getElementById("productList");

    if (!products.length) {
      container.innerHTML = "<p>Tidak ada produk untuk saat ini.</p>";
      return;
    }

    container.innerHTML = products.map(p => `
      <div class="product">
        <img src="${p.image || 'images/logo.png'}" alt="${p.name}">
        <h3>${p.name}</h3>
        ${p.discount && p.discount > 0 ? `
          <p class="old-price">Rp ${(p.price).toLocaleString()}</p>
          <p class="price">Rp ${(p.price - (p.price * p.discount / 100)).toLocaleString()} <span class="diskon">-${p.discount}%</span></p>
        ` : `
          <p class="price">Rp ${(p.price).toLocaleString()}</p>
        `}
        <button class="btn" onclick="buyProduct('${p._id}')">Beli Sekarang</button>
      </div>
    `).join("");
  } catch (err) {
    console.error(err);
  }
}

// === Fungsi Beli Produk ===
async function buyProduct(productId) {
  const user = JSON.parse(localStorage.getItem("user"));
  if (!user) {
    alert("Silakan login terlebih dahulu!");
    window.location.href = "login.html";
    return;
  }

  const kodeVoucher = prompt("Masukkan kode voucher (jika ada):") || "";
  const res = await fetch("/api/buy-product", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId: user._id, productId, kodeVoucher })
  });

  const data = await res.json();
  alert(data.message);
  if (data.success) window.location.href = "dashboard.html";
}

// === Tambahan gaya untuk harga coret ===
const style = document.createElement('style');
style.innerHTML = `
.old-price {
  text-decoration: line-through;
  color: #888;
  font-size: 0.9em;
}
.diskon {
  background: #005bff;
  color: #fff;
  padding: 2px 6px;
  border-radius: 5px;
  font-size: 0.8em;
}
`;
document.head.appendChild(style);